package com.mph.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mph.entity.User;
import com.mph.service.UserService;

@RestController
@RequestMapping("/user")
public class UserController {

	@Autowired
   private UserService userService;

	@GetMapping("/All")
    public List<User> getAllUser() {
    	System.out.println("Entry point");

    	return   userService.getAllUser();
        
	}

    @GetMapping("/{userId}")
    public User getUser(@PathVariable("userId") Long userId) {
    	System.out.println("Entry point");

        User user = this.userService.getUser(userId);
        
        return user;

    }

}