package com.mph.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.mph.Dao.UserDao;
import com.mph.entity.User;

public class UserService {
	
	@Autowired 
	UserDao userDao;
	
	 public User getUser(Long id) {
		 return userDao.getById(id);
	 }

	public List<User> getAllUser(){
		return userDao.findAll();
	};

}
