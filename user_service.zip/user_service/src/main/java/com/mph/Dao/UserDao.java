package com.mph.Dao;
import org.springframework.data.jpa.repository.JpaRepository;

import com.mph.entity.*;
public interface UserDao extends JpaRepository<User,Long> {

}
