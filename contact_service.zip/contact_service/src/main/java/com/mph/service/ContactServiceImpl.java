package com.mph.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mph.entity.Contact;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ContactServiceImpl implements ContactService {

    //fake user list
	@Autowired
	UserDao userDao;
   

	@Override
	public List<Contact> getContactofUser(Long userId) {
		
	return 
	}
}