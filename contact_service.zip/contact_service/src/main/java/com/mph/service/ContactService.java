package com.mph.service;

import java.util.List;

import com.mph.entity.Contact;

public interface ContactService {
	 public List<Contact> getContactofUser(Long userId);

}
